package Queues;

/**
 * Created with IntelliJ IDEA.
 * User: Brandon
 * Date: 9/26/14
 * Time: 5:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class Dequeue {
    private int maxSize;
    private long[] queArray;
    private int left;
    private int right;
    private int middle;

    public Dequeue(int s){
        maxSize = s+1;
        middle = (maxSize / 2);
        left = middle - 1;
        right = middle + 1;
    }
    public void insertLeft(long n){
        if(left==0)                  //make sure left has room
            left = middle-1;         //if not, wrap around
        queArray[--left] = n;        //insert element
    }
    public void insertRight(long n){
        if(right==maxSize-1)        //make sure right has room
            right = middle+1;       //if not, wrap around
        queArray[++right] = n;       //insert element
    }
    public long removeLeft(){
        long temp = queArray[left++];  //create temp variable
        if(left == 0)                  //check for wrap around
            left = middle-1;
        return temp;
    }
    public long removeRight(){
        long temp = queArray[right++]; //create temp variable
        if(right == maxSize)          //check for wrap around
            right = middle-1;
        return temp;
    }
    public boolean isEmpty(){
        return (left+1==right || (left==right)); // if left and right pointers are together, array is empty
    }
    public boolean isFull(){
        return (left==0 && right == maxSize);  // if left is at the index 0 and right is at index max size, array is Full
    }
}
