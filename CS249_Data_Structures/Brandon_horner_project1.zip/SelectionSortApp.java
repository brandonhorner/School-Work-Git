package Sorting;

/**
 * Created by Brandon on 9/26/14.
 */
public class SelectionSortApp {
    public static void main(String[] args) {
        int maxSize = 100;
        SelectionSort unsorted = new SelectionSort(maxSize);
        SelectionSort almostSorted = new SelectionSort(maxSize);
        SelectionSort revSorted = new SelectionSort(maxSize);
        revSorted.insert(99);

        revSorted.insert(88);
        revSorted.insert(77);
        revSorted.insert(66);
        revSorted.insert(55);
        revSorted.insert(44);
        revSorted.insert(33);
        revSorted.insert(22);
        revSorted.insert(11);
        revSorted.insert(00);
        almostSorted.insert(00);

        almostSorted.insert(11);
        almostSorted.insert(55);
        almostSorted.insert(33);
        almostSorted.insert(22);
        almostSorted.insert(66);
        almostSorted.insert(77);
        almostSorted.insert(88);
        almostSorted.insert(99);
        almostSorted.insert(44);
        unsorted.insert(77);         //insert values to arr

        unsorted.insert(99);
        unsorted.insert(44);
        unsorted.insert(55);
        unsorted.insert(22);
        unsorted.insert(88);
        unsorted.insert(11);
        unsorted.insert(00);
        unsorted.insert(66);
        unsorted.insert(33);
        System.out.println("\nReverse Sorted Array: ");

        revSorted.display();
        System.out.println("");
        revSorted.selectionSort();
        revSorted.display();
        System.out.println("\nAlmost Sorted Array: ");

        almostSorted.display();
        System.out.println("");
        almostSorted.selectionSort();
        almostSorted.display();
        System.out.println("\nUnsorted Array: ");
        unsorted.display();            //display before sort
        System.out.println("");
        unsorted.selectionSort();      //sort
        unsorted.display();            //display after sort
    }
}
