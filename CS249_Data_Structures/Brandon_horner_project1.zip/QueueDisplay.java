package Queues;

/**
 * Created with IntelliJ IDEA.
 * User: Brandon
 * Date: 9/26/14
 * Time: 4:37 PM
 * To change this template use File | Settings | File Templates.
 */
public class QueueDisplay {
    public static void main(String[] args) {
        Queue current;
        current = new Queue(5);
        Queue one;
        one = new Queue(1);
        Queue none;
        none = new Queue(0);

        System.out.println("\nArray with no item: ");
        none.display();

        System.out.println("\nArray with one item: ");
        one.insert(5);
        one.display();

        current.insert(5);
        current.insert(10);
        current.insert(15);
        current.insert(20);
        current.insert(25);
        System.out.println("\nArray with five items: ");
        current.display();

        current.remove();
        current.remove();

        System.out.println("\nTwice removed: ");
        current.display();
        current.insert(30);
        current.insert(35);
        System.out.println("\nAdding two new elements: ");
        current.display();

        current.remove();
        current.remove();
        current.remove();
        current.remove();
        current.insert(40);
        current.insert(45);
        current.insert(50);
        current.insert(55);
        System.out.println("\nRemoving 4 elements and adding 4 different ones: ");
        current.display();




    }
}
