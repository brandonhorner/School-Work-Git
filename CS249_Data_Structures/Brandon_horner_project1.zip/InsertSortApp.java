package Sorting;

/**
 * Created with IntelliJ IDEA.
 * User: Brandon
 * Date: 9/26/14
 * Time: 7:59 AM
 * To change this template use File | Settings | File Templates.
 */
public class InsertSortApp {
    public static void main(String[] args){
        int maxSize = 100;
        InsertionSort unsorted = new InsertionSort(maxSize);
        InsertionSort almostSorted = new InsertionSort(maxSize);
        InsertionSort revSorted = new InsertionSort(maxSize);

        revSorted.insert(99);
        revSorted.insert(88);
        revSorted.insert(77);
        revSorted.insert(66);
        revSorted.insert(55);
        revSorted.insert(44);
        revSorted.insert(33);
        revSorted.insert(22);
        revSorted.insert(11);
        revSorted.insert(00);

        almostSorted.insert(00);
        almostSorted.insert(11);
        almostSorted.insert(55);
        almostSorted.insert(33);
        almostSorted.insert(22);
        almostSorted.insert(66);
        almostSorted.insert(77);
        almostSorted.insert(88);
        almostSorted.insert(99);
        almostSorted.insert(44);

        unsorted.insert(77);         //insert values to arr
        unsorted.insert(99);
        unsorted.insert(44);
        unsorted.insert(55);
        unsorted.insert(22);
        unsorted.insert(88);
        unsorted.insert(11);
        unsorted.insert(00);
        unsorted.insert(66);
        unsorted.insert(33);

        System.out.println("\nReverse Sorted Array: ");
        revSorted.display();
        System.out.println("");
        revSorted.insertionSort();
        revSorted.display();

        System.out.println("\nAlmost Sorted Array: ");
        almostSorted.display();
        System.out.println("");
        almostSorted.insertionSort();
        almostSorted.display();
        System.out.println("\nUnsorted Array: ");
        unsorted.display();            //display before sort
        System.out.println("");
        unsorted.insertionSort();      //sort
        unsorted.display();            //display after sort


    }//end main
}//end InsertSortApp
