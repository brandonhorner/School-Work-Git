package Queues;

/**
 * Created with IntelliJ IDEA.
 * User: Brandon
 * Date: 9/26/14
 * Time: 5:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class DequeueDisplay {
    public static void main(String[] args) {
        int size = 5;
        Dequeue current;
        current = new Dequeue(size);
    }
}
