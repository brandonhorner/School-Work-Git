package Queues;

/**
 * Created with IntelliJ IDEA.
 * User: Brandon
 * Date: 9/26/14
 * Time: 4:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class Queue {
    private int maxSize;
    private long[] queArray;
    private int front;
    private int rear;

    public Queue(int size){
        maxSize = size+1;
        queArray = new long[maxSize];
        front = 0;
        rear = -1;
    }
    public void insert(long j){
        if(rear==maxSize-1)
            rear = -1;
        queArray[++rear] = j;
    }
    public long remove(){
        long temp = queArray[front++];
        if(front == maxSize)
            front = 0;
        return temp;
    }
    public long peek(){
        return queArray[front];
    }
    public boolean isEmpty(){
        return (rear+1==front || (front+maxSize-1==rear));
    }
    public boolean isFull(){
        return(rear+2==front || (front+maxSize-2==rear));
    }
    public int size(){
        if(rear>=front)
            return rear-front+1;
        else
            return (maxSize-front) + (rear+1);
    }
    public void display(){
        if(!isEmpty()){     //if not empty
            if(front>rear){ //handle wrap around
                for (int j=front; j<=maxSize-1; j++) //start from front to end of array
                    System.out.print(queArray[j] + " ");
                for (int j=0; j<=rear; j++) //start at beginning of array to rear
                    System.out.print(queArray[j] + " ");
            }else{ //not wrapping around
                for (int j=front; j<=rear; j++){
                    System.out.print(queArray[j] + " ");
                }
            }
        }else
            System.out.print("Queue is empty.");
    }
}//end class Queue

