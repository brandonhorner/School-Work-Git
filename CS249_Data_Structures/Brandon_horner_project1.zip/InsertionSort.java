package Sorting;

/**
 * Created by Brandon on 2/25/14.
 */
public class InsertionSort{

    private long[] a;   //ref to array a
    private int nElems;  //number of data items
    private int copies;
    private int comparisons;

    public InsertionSort(int max){
        a = new long[max];
        nElems = 0;
        copies = 0;
        comparisons = 0;
    }
    public void insert(long value){
        a[nElems] = value;  //insert value
        nElems++;  //increment size
    }
    public void display(){
        for(int j=0; j<nElems; j++)
            System.out.print(a[j] + " ");
    }
    public void insertionSort(){
        for(int out=1; out<nElems; out++){
            comparisons+=1;
            long temp = a[out];
            int in = out;
            while(in>0 && a[in-1] >= temp){
                copies+=1;
                a[in] = a[in-1];
                --in;
            }//end while
            a[in] = temp;
        }//end for
        System.out.println("Comparisons: " + comparisons);
        System.out.println("Copies: " + copies);
    }//end insertion sort
}
