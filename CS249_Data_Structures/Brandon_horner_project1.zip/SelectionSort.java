package Sorting;
/**
 * Created with IntelliJ IDEA.
 * User: Brandon
 * Date: 9/26/14
 * Time: 8:33 AM
 * To change this template use File | Settings | File Templates.
 */
public class SelectionSort {

    /* Selection Sort
        1) Look at all elements + select the smallest (initially first element of array)
        2) Swap the smallest # with the beginning of unsorted portion of the array
        3) swap the element from that space
        4) repeat on remaining unsorted portion of the array

        Invariant: left side of next element to be sorted is always
        sorted (in the final resting position)
    */
    private int[] a;   //ref to array a
    private int nElems;  //number of data items
    private int copies;
    private int comparisons;

    public SelectionSort(int max){
        a = new int[max];
        nElems = 0;
        copies = 0;
        comparisons = 0;
    }
    public void insert(int value){
        a[nElems] = value;  //insert value
        nElems++;  //increment size
    }

    public void display(){
        for(int j=0; j<nElems; j++)
            System.out.print(a[j] + " ");
    }

    public void selectionSort() {
        int i, j, first, temp;
        for(i=0; i<nElems; i++){ //traverse array swapping smallest value with front index of the array
            first = i;      //update front of array as we go (beginning part will be sorted)
            comparisons+=1;
            for(j=i+1; j<nElems; j++){  //traverse the array beyond i each time to find the min in the unsorted array
                if(a[j] < a[first]){ //if the value found is smaller than first item looked at
                    first = j;   //update first to the index of smallest item
                    copies+=1;
                }
            }//end for
            temp = a[first];   //swap first (smallest item) with current starting point (arr[i])
            a[first] = a[i];
            a[i] = temp;
        }
        System.out.println("Comparisons: " + comparisons);
        System.out.println("Copies: " + copies);
    }
}
