package Sorting;

/**
 * Created by Brandon on 9/26/14.
 */
public class BubbleSort {
    private int[] a;   //ref to array a
    private int nElems;  //number of data items
    private int copies;
    private int comparisons;
    public BubbleSort(int max){
        a = new int[max];
        nElems = 0;
    }

    public void insert(int value){
        a[nElems] = value;  //insert value
        nElems++;  //increment size
    }

    public void Bubble(){
    /* BubbleSort invariant: During each pass; the largest number is put at the
     * rightmost position that hasn't been used.
     */
        int temp = -1;
        boolean flag = true;
        while(flag){
            flag = false;
            comparisons+=1;
            for(int i=1; i<nElems; i++){
                if(a[i-1]>a[i]){
                    copies++;
                    temp = a[i];  //store smaller in temp
                    a[i] = a[i-1]; //update smaller numbers index to bigger number
                    a[i-1] = temp; //put smaller number in previous index
                    flag = true; //swap occurred
                }
            }
        }
        System.out.println("\n" + "Comparisons: " + Integer.toString(comparisons));
        System.out.println("Copies: " + Integer.toString(copies));
     }
    public void display(){
        for(int j=0; j<nElems; j++)
            System.out.print(a[j] + " ");
    }

}//end class BubbleSort
